AL SAFA — Website package

Files:
- index.html       Main page
- css/style.css    Responsive design and visual styling
- js/main.js       Copy-phone interaction and current year
- assets/logo.webp Original logo extracted from your uploaded page

Upload the contents of this folder to the public root folder of your free hosting
(for example: public_html, htdocs, or the repository root for GitHub Pages).
Keep the folder structure unchanged.

The page uses the same black-and-gold identity and keeps the original Behance,
WhatsApp, and phone destinations. Google Fonts is optional; the page has fallbacks.
